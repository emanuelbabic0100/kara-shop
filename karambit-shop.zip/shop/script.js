/* ============================================================
   POSTAVKE – ovdje mijenjaš cijene i nazive
   ============================================================ */
const KNIFE_PRICE = 19.99;   // cijena noža u € (promijeni po želji)
const STAND_PRICE = 7.99;    // cijena stalka u €

const PRODUCTS = [
  { id: 'black',  name: 'Crni karambit',     color: '#222222', price: KNIFE_PRICE,
    options: [{ label: 'Opcija 1', img: 'images/black.jpg' },  { label: 'Opcija 2', img: 'images/black_2.jpg' }] },
  { id: 'blue',   name: 'Plavi karambit',    color: '#1e6bff', price: KNIFE_PRICE,
    options: [{ label: 'Opcija 1', img: 'images/blue.jpg' },   { label: 'Opcija 2', img: 'images/blue_2.jpg' }] },
  { id: 'purple', name: 'Ljubičasti karambit (duga)', color: '#a45cff', price: KNIFE_PRICE,
    options: [{ label: 'Opcija 1', img: 'images/purple.jpg' }, { label: 'Opcija 2', img: 'images/purple_2.jpg' }] },
  { id: 'red',    name: 'Crveni karambit',   color: '#e0262b', price: KNIFE_PRICE,
    options: [{ label: 'Opcija 1', img: 'images/red.jpg' },    { label: 'Opcija 2', img: 'images/red_2.jpg' }] },
  { id: 'yellow', name: 'Žuti (zlatni) karambit', color: '#f2c21b', price: KNIFE_PRICE,
    options: [{ label: 'Opcija 1', img: 'images/yellow.jpg' }, { label: 'Opcija 2', img: 'images/yellow_2.jpg' }] },
  { id: 'stand',  name: 'Stalak za nož',     color: '#555', price: STAND_PRICE, tag: 'Dodatak',
    options: [{ label: 'Standard', img: 'images/stand.jpg' }] },
];

/* ============================================================ */
const $ = s => document.querySelector(s);
const fmt = n => n.toFixed(2).replace('.', ',') + ' €';
const selected = {};              // odabrana opcija po proizvodu
let cart = [];                    // [{key,id,optIndex,qty}]
try { cart = JSON.parse(localStorage.getItem('cart') || '[]'); } catch (e) {}

const save = () => { try { localStorage.setItem('cart', JSON.stringify(cart)); } catch (e) {} };
const find = id => PRODUCTS.find(p => p.id === id);

/* ---------- proizvodi ---------- */
function renderGrid() {
  $('#grid').innerHTML = PRODUCTS.map(p => {
    selected[p.id] ??= 0;
    const o = p.options[selected[p.id]];
    const opts = p.options.length > 1
      ? `<div class="opts">${p.options.map((x, i) =>
          `<button class="opt ${i === selected[p.id] ? 'active' : ''}" data-id="${p.id}" data-i="${i}">${x.label}</button>`).join('')}</div>`
      : '';
    return `
      <article class="card">
        <div class="img"><img id="img-${p.id}" src="${o.img}" alt="${p.name}"></div>
        <div class="body">
          <h3><span class="dot" style="background:${p.color}"></span>${p.name} ${p.tag ? `<span class="tag">${p.tag}</span>` : ''}</h3>
          ${opts}
          <div class="price">${fmt(p.price)}<small>+ besplatna dostava</small></div>
          <button class="btn add" data-id="${p.id}">Dodaj u košaricu</button>
        </div>
      </article>`;
  }).join('');
}

$('#grid').addEventListener('click', e => {
  const opt = e.target.closest('.opt');
  if (opt) {
    const { id, i } = opt.dataset;
    selected[id] = +i;
    $('#img-' + id).src = find(id).options[+i].img;
    opt.parentElement.querySelectorAll('.opt').forEach(b => b.classList.toggle('active', b === opt));
    return;
  }
  const add = e.target.closest('.add');
  if (add) addToCart(add.dataset.id, selected[add.dataset.id]);
});

/* ---------- košarica ---------- */
function addToCart(id, optIndex) {
  const key = id + ':' + optIndex;
  const it = cart.find(c => c.key === key);
  it ? it.qty++ : cart.push({ key, id, optIndex, qty: 1 });
  save(); renderCart(); toast('Dodano u košaricu ✓');
}

const total = () => cart.reduce((s, c) => s + find(c.id).price * c.qty, 0);

function renderCart() {
  const count = cart.reduce((s, c) => s + c.qty, 0);
  $('#cartCount').textContent = count;
  $('#subtotal').textContent = fmt(total());
  $('#total').textContent = fmt(total());
  $('#checkoutBtn').disabled = !count;
  $('#cartItems').innerHTML = count ? cart.map(c => {
    const p = find(c.id), o = p.options[c.optIndex];
    return `
      <div class="item">
        <img src="${o.img}" alt="">
        <div class="meta"><b>${p.name}</b><span>${o.label} · ${fmt(p.price)}</span>
          <div class="qty">
            <button data-act="dec" data-key="${c.key}">−</button>${c.qty}
            <button data-act="inc" data-key="${c.key}">+</button>
          </div>
        </div>
        <button class="rm" data-act="rm" data-key="${c.key}">Ukloni</button>
      </div>`;
  }).join('') : '<p class="empty">Košarica je prazna.</p>';
}

$('#cartItems').addEventListener('click', e => {
  const b = e.target.closest('button[data-act]'); if (!b) return;
  const it = cart.find(c => c.key === b.dataset.key); if (!it) return;
  if (b.dataset.act === 'inc') it.qty++;
  if (b.dataset.act === 'dec') it.qty--;
  if (b.dataset.act === 'rm') it.qty = 0;
  cart = cart.filter(c => c.qty > 0);
  save(); renderCart();
});

const drawer = (open) => {
  $('#drawer').classList.toggle('open', open);
  $('#overlay').classList.toggle('show', open);
  $('#drawer').setAttribute('aria-hidden', !open);
};
$('#openCart').onclick = () => drawer(true);
$('#closeCart').onclick = $('#overlay').onclick = () => drawer(false);

/* ---------- plaćanje karticom ---------- */
const modal = $('#modal');
$('#checkoutBtn').onclick = () => {
  if (!cart.length) return;
  drawer(false);
  $('#payTotal').textContent = fmt(total());
  $('#formErr').textContent = '';
  modal.classList.add('open');
};
$('#closeModal').onclick = () => modal.classList.remove('open');

const form = $('#checkoutForm');
form.card.addEventListener('input', e => {
  e.target.value = e.target.value.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
});
form.exp.addEventListener('input', e => {
  let v = e.target.value.replace(/\D/g, '').slice(0, 4);
  if (v.length > 2) v = v.slice(0, 2) + '/' + v.slice(2);
  e.target.value = v;
});
form.cvc.addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g, ''));

// Luhn provjera broja kartice
const luhn = n => {
  let s = 0, d = false;
  for (let i = n.length - 1; i >= 0; i--) {
    let x = +n[i]; if (d) { x *= 2; if (x > 9) x -= 9; } s += x; d = !d;
  }
  return n.length >= 13 && s % 10 === 0;
};

form.addEventListener('submit', async e => {
  e.preventDefault();
  const err = $('#formErr'); err.textContent = '';
  form.querySelectorAll('input').forEach(i => i.classList.remove('bad'));
  const bad = [];
  ['name', 'email', 'address', 'city', 'zip', 'country'].forEach(n => { if (!form[n].value.trim()) bad.push(n); });
  if (!/^\S+@\S+\.\S+$/.test(form.email.value)) bad.push('email');
  if (!luhn(form.card.value.replace(/\s/g, ''))) bad.push('card');
  const m = form.exp.value.match(/^(\d\d)\/(\d\d)$/);
  if (!m || +m[1] < 1 || +m[1] > 12) bad.push('exp');
  if (!/^\d{3,4}$/.test(form.cvc.value)) bad.push('cvc');
  if (bad.length) {
    bad.forEach(n => form[n].classList.add('bad'));
    err.textContent = 'Provjeri označena polja.'; return;
  }

  const btn = $('#payBtn'); btn.disabled = true;
  try {
    /* --------------------------------------------------------
       OVDJE SE SPAJA PRAVO PLAĆANJE (Stripe / Monri / CorvusPay…).
       Podaci kartice se NIKAD ne šalju na vlastiti server –
       to radi pružatelj plaćanja. Dolje je samo simulacija.
       -------------------------------------------------------- */
    await new Promise(r => setTimeout(r, 1200));
    cart = []; save(); renderCart(); form.reset(); form.country.value = 'Hrvatska';
    modal.classList.remove('open');
    toast('Narudžba zaprimljena! (demo) 🎉');
  } catch (x) {
    err.textContent = 'Plaćanje nije uspjelo. Pokušaj ponovno.';
  } finally { btn.disabled = false; }
});

function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 1800);
}

$('#year').textContent = new Date().getFullYear();
renderGrid(); renderCart();
